package ch02.ooprogramming;

// 8. In the preceding exercises, providing the constructors and getter methods of the
// Point class was rather repetitive. Most IDEs provide shortcuts for writing the
// boilerplate code. What does your IDE offer?

// Eclipse has facilities for automatically generating getters, setters, hashCode,
// equals, toString, constructors, element comments, etc.

public class Ch0208IDE {

  public static void main(String[] args) {
    // TODO Auto-generated method stub

  }

}
