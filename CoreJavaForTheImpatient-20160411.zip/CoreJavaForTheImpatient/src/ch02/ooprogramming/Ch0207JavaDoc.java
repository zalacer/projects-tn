package ch02.ooprogramming;

// 7. Add javadoc comments to both versions of the Point class from the preceding
// exercises.

// Ch0205Point.java and Ch0206PointMutator.jave have been javadoc commented
// the javadocs are in CoreJavaForTheImpatient-Ch02-javadoc.zip

public class Ch0207JavaDoc {

  //    public static void main(String[] args) {
  //        // TODO Auto-generated method stub
  //
  //    }

}
