package ch06.generics;

// 24. Which methods can you call on a variable of type Class<?> without using casts?

// Instance methods of Class.class. 

public class Ch0624ClassQuestionMark {

  public static void main(String[] args) {


  }

}
