package utils;

// for Ch0209Car
public enum Direction {
    EAST, WEST
}
