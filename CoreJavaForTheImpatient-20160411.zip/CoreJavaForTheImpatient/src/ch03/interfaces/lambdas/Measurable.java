package ch03.interfaces.lambdas;

public interface Measurable {
  double getMeasure();
}
