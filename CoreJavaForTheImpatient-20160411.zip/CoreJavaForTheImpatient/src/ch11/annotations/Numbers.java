package ch11.annotations;

public enum Numbers {
  ONE, TWO, THREE, FOUR, FIVE
}
