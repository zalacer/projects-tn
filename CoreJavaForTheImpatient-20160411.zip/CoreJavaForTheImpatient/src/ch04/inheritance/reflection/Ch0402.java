package ch04.inheritance.reflection;

// 2. Define toString, equals, and hashCode methods for the classes of the
// preceding exercise (Point and LabeledPoint)

// done - see those classes, note that LabelledPoint is in package utils1

public class Ch0402 {

}
