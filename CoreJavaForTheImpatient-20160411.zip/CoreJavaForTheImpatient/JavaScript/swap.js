
function swap(a,i,j) {
	tmp = a[i]
	a[i] = a[j]
	a[j] = tmp
}
var cars = ["Saab", "Volvo", "BMW"]
print(cars[i])
swap(cars, 0, 2)
print('after')
for (var i = 0; i < cars.length; i++) {
    print(cars[i])
}

print(cars)
