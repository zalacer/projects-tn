print("one")
