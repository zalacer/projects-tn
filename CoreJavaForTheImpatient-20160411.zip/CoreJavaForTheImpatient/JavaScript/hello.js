
var it = 1
function hello() { print('rok '+it) }
hello()